<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <textarea <?php echo e($attributes); ?>><?php echo e($value ?? ''); ?></textarea>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\George\Dropbox\THEMEFOREST\BeShop - Beauty Store App\04_REACT-NATIVE-ADMIN\admin\vendor\orchid\platform\resources\views/fields/textarea.blade.php ENDPATH**/ ?>